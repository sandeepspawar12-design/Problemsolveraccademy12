# Problem Solver Academy — Android project

This is an Android Studio project wrapping the Problem Solver Academy learning app in a native Android WebView. The app content is bundled locally and does not need an internet connection.

## Build the APK

1. Install **Android Studio** on a computer and open this project folder.
2. Allow Android Studio to install the Android SDK Platform 35 and any requested build tools.
3. Wait for Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When the build finishes, click **locate** in the notification. The APK is normally at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer `app-debug.apk` to your Android phone, open it, and allow installation from that source if Android asks.

## Notes

- Application ID: `com.problemsolveracademy.app`
- Version: `1.0` (debug build)
- Minimum Android version: Android 6.0 (API 23)
- The debug APK is suitable for personal testing. A Play Store release needs a signed release build.
- The current coding environment did not have the Android SDK/Gradle installed and could not reach Google's download servers, so this archive contains the buildable project source, not a compiled APK.
